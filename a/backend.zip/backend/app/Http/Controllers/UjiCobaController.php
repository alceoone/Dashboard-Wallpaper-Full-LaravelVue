<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UjiCobaController extends Controller
{
    public function ujicoba () {
        return 'ujivona';
    }
}
